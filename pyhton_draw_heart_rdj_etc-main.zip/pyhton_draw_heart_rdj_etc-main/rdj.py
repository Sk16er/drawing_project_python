# Importing sketchpy module
# to install skectpy : pip install sketchpy

from sketchpy import library as lib

#creating object of rdj()
obj = lib.rdj()

# Callling Draw method
obj.draw()
